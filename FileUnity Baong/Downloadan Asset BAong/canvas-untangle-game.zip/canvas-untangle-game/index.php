<?php

	$conn = mysqli_connect("sql107.infinityfree.com","if0_35422848","NqWcpenaKA","if0_35422848_leaderboard");

	
	//while($skor = mysqli_fetch_assoc($result)){
		//var_dump($skor["Nama"]);
	//}
	
	

	$result = mysqli_query($conn, "SELECT * FROM urutan ORDER BY Skor DESC LIMIT 0,5");

?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title></title>
  <link href='http://fonts.googleapis.com/css?family=Rock+Salt' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/untangle.css" />
</head>
<body>
	<section id="page">
		<header>
			<h1></h1>
		</header>
		<div class = "MainMenu" id = "MainMenu" style = "display : inline-block">
		
			<a href = "#" onclick = "startGame() "><img class = "BG_MainMenu" src="images/StartEdit.png" alt=""></a>
			<br>
			
			<table>
				<thead>
					<tr>
						<th>No.</th>
						<th>Nama</th>
						<th>Skor</th>
					</tr>
				</thead>
			<?php $i = 1;?>
			<?php while($skor = mysqli_fetch_assoc($result)) :?> 
				<tbody>
					<tr>
						<td><?= $i ?></td>
						<td><?= $skor["Nama"] ?></td>
						<td><?= $skor["Skor"] ?></td>
					</tr>
				</tbody>
			<?php $i++;?>
			<?php endwhile; ?>	
			</table>
	
			
			


		</div>

		<div class = "GameOver" id = "GameOver" style = "display : none">

			<h1>Game Over</h1>
			<form action = "End_Page.php" method = "post" id = "form">

				<p id ="SkorGame">INI SKOR</p>
				<input style = "display : none" type = "number" name = "Skor" id = "Skor">
				<label for = "lNama">Nama</label>
				<br>
				<br>
				<input type = "text" name = "Nama" id = "lNama">
				<br>
				<br>
				<button class = "IMGSubmit" href = "#" type = "submit" name = "submit"><img  src="images/SUBMIT.png" alt=""></button>

			</form>
			
		</div>

		<div id="layers"  style = "display : none">
		  <canvas id="bg" width="768" height="400">
		    This is an interactive game with circles and lines connecting them.
		  </canvas>
		  <canvas id="guide" width="768" height="400"></canvas>
		  <canvas id="game" width="768" height="400"></canvas>
		  <canvas id="ui" width="768" height="400"></canvas>

		 
		</div>
		
	</section>

<script src="js/jquery-2.1.3.min.js"></script>
<script src="js/untangle.data.js"></script>
<script src="js/untangle.drawing.js"></script>
<script src="js/untangle.input.js"></script>
<script src="js/untangle.levels.js"></script>
<script src="js/untangle.game.js"></script>
<script src="js/untangle.js"></script>
</body>
</html>

