<?php 

$conn = mysqli_connect("sql107.infinityfree.com","if0_35422848","NqWcpenaKA","if0_35422848_leaderboard");


if(isset($_POST["submit"])){
    $skor = $_POST["Skor"];
    $nama = $_POST["Nama"];
    

    $wari = "INSERT INTO urutan
                VALUES
                ('','$nama','$skor')
                ";
    
    mysqli_query($conn, $wari);
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Untwist</title>
  <link href='http://fonts.googleapis.com/css?family=Rock+Salt' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/untangle.css" />
</head>
<body>
	<section id="page">
		<header>
			<h1></h1>
		</header>
		<div class = "MainMenu" id = "MainMenu" style = "display : inline-block">

            <h1> Terima Kasih </h1>

			<a href = "Index.php"><img class = "IMGKembali" src="images/KEMBALI.png" alt=""></a>
			
		</div>

		<div id="layers"  style = "display : none">
		  <canvas id="bg" width="768" height="400">
		    This is an interactive game with circles and lines connecting them.
		  </canvas>
		  <canvas id="guide" width="768" height="400"></canvas>
		  <canvas id="game" width="768" height="400"></canvas>
		  <canvas id="ui" width="768" height="400"></canvas>

		 
		</div>


		
	</section>

<script src="js/jquery-2.1.3.min.js"></script>
<script src="js/untangle.data.js"></script>
<script src="js/untangle.drawing.js"></script>
<script src="js/untangle.input.js"></script>
<script src="js/untangle.levels.js"></script>
<script src="js/untangle.game.js"></script>
<script src="js/untangle.js"></script>

<script>
    

        if ( window.history.replaceState ) {
    window.history.replaceState( null, null, window.location.href );
    }

</script>
</body>
</html>