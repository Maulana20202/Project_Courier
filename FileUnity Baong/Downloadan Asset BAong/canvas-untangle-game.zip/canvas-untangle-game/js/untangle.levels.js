if (untangleGame === undefined) {
  var untangleGame = {};
}

// levels data
untangleGame.levels = [
  {
    circles : [
      {x : 400, y : 156},
      {x : 381, y : 241},
      {x : 84, y : 233},
      {x : 88, y : 73}],
    relationship : [
      {connectedPoints : [1,2]},
      {connectedPoints : [0,3]},
      {connectedPoints : [0,3]},
      {connectedPoints : [1,2]}
    ]
  },
  {
    circles : [
      {x : 401, y : 73},
      {x : 400, y : 240},
      {x : 88, y : 241},
      {x : 84, y : 72}],
    relationship : [
      {connectedPoints : [1,2,3]},
      {connectedPoints : [0,2,3]},
      {connectedPoints : [0,1,3]},
      {connectedPoints : [0,1,2]}
    ]
  },
  {
    circles : [
      {x : 192, y : 155},
      {x : 353, y : 109},
      {x : 493, y : 156},
      {x : 490, y : 236},
      {x : 348, y : 276},
      {x : 195, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  ,
  {
    circles : [
      {x : 192, y : 155},
      {x : 228, y : 109},
      {x : 155, y : 156},
      {x : 490, y : 192},
      {x : 156, y : 276},
      {x : 195, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  , 
  {
    circles : [
      {x : 192, y : 155},
      {x : 228, y : 109},
      {x : 155, y : 156},
      {x : 490, y : 192},
      {x : 156, y : 276},
      {x : 195, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  },
  {
    circles : [
      {x : 250, y : 155},
      {x : 228, y : 50},
      {x : 200, y : 156},
      {x : 500, y : 180},
      {x : 156, y : 276},
      {x : 402, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  ,
  {
    circles : [
      {x : 300, y : 155},
      {x : 228, y : 280},
      {x : 650, y : 156},
      {x : 490, y : 200},
      {x : 180, y : 276},
      {x : 195, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  ,
  {
    circles : [
      {x : 300, y : 155},
      {x : 228, y : 280},
      {x : 650, y : 300},
      {x : 490, y : 200},
      {x : 100, y : 276},
      {x : 100, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  ,
  {
    circles : [
      {x : 192, y : 155},
      {x : 100, y : 109},
      {x : 250, y : 250},
      {x : 490, y : 192},
      {x : 100, y : 200},
      {x : 195, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  ,
  {
    circles : [
      {x : 500, y : 155},
      {x : 228, y : 200},
      {x : 300, y : 156},
      {x : 490, y : 200},
      {x : 156, y : 276},
      {x : 180, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  ,
  {
    circles : [
      {x : 192, y : 155},
      {x : 228, y : 250},
      {x : 155, y : 156},
      {x : 200, y : 180},
      {x : 156, y : 276},
      {x : 195, y : 170}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  ,
  {
    circles : [
      {x : 700, y : 155},
      {x : 228, y : 250},
      {x : 800, y : 156},
      {x : 120, y : 192},
      {x : 156, y : 150},
      {x : 195, y : 228}],
    relationship : [
      {connectedPoints : [2,3,4]},
      {connectedPoints : [3,5]},
      {connectedPoints : [0,4,5]},
      {connectedPoints : [0,1,5]},
      {connectedPoints : [0,2]},
      {connectedPoints : [1,2,3]}
    ]
  }
  ,
  {
    circles : [
      {x : 180, y : 155},
      {x : 228, y : 109},
      {x : 155, y : 156},
      {x : 490, y : 192}],
    relationship : [
      {connectedPoints : [2,3,1]},
      {connectedPoints : [3,2]},
      {connectedPoints : [0,2,1]},
      {connectedPoints : [0,1,3]},
    ]
  }
  
];
