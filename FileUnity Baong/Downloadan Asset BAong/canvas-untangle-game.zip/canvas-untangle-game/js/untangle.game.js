if (untangleGame === undefined) {
  var untangleGame = {};
}

untangleGame.currentLevel = 0;
untangleGame.levelProgress = 0;
untangleGame.Skor = 0;
untangleGame.Time =10;

untangleGame.setupCurrentLevel = function() {
  untangleGame.circles = [];
  var level = untangleGame.levels[untangleGame.currentLevel];
  for (var i=0; i<level.circles.length; i++) {
    untangleGame.circles.push(new untangleGame.Circle(level.circles[i].x, level.
    circles[i].y, 10));
    
  }

  untangleGame.levelProgress = 0;

  // setup line data after setup the circles.
  untangleGame.CheckTime();
  untangleGame.connectCircles();
  untangleGame.updateLineIntersection();
  untangleGame.checkLevelCompleteness();
  untangleGame.updateLevelProgress();
  untangleGame.selesaiGame();
};

untangleGame.checkLevelCompleteness = function() {
  if (untangleGame.levelProgress === 100) {
    if (untangleGame.currentLevel+1 < untangleGame.levels.length) {
      untangleGame.currentLevel+=1;
      if(untangleGame.Time > 5){
        untangleGame.Skor += 100;
      } else if (untangleGame.Time < 5 && untangleGame.Time > 0){
        untangleGame.Skor += 50;
      } else {
        untangleGame.Skor += 0;
      }
      
    }
    untangleGame.setupCurrentLevel();
    untangleGame.Time = 10;
  } 
};

untangleGame.selesaiGame = function() {
  if (untangleGame.currentLevel >= untangleGame.levels.length - 1){
    SkorCalling()
    overGame()
    
  }
  
};

untangleGame.CheckTime = function(){
  if (untangleGame.Time <= 0){
    SkorCalling()
    overGame()
    
  }
}

untangleGame.updateLevelProgress = function() {
  // check the untangle progress of the level
  var progress = 0;
  for (var i=0;i<untangleGame.lines.length;i++) {
    if (untangleGame.lines[i].thickness === untangleGame.
    thinLineThickness) {
      progress+=1;
    }
  }
  var progressPercentage = Math.floor(progress/untangleGame.lines.length*100);

  untangleGame.levelProgress = progressPercentage;

  $("#progress").text(progressPercentage);

  // display the current level
  $("#level").text(untangleGame.currentLevel);
};


function startGame(){
  let MainMenu = document.getElementById("MainMenu");
  let layers = document.getElementById("layers");
  let gameOver = document.getElementById("GameOver");

  MainMenu.style.display = "none";
  layers.style.display = "inline-block";
  gameOver.style.display = "none";
  StartTimer()
  untangleGame.Skor = 0;
  untangleGame.currentLevel = 0;
  untangleGame.setupCurrentLevel();
  
}

function overGame(){
  let MainMenu = document.getElementById("MainMenu");
  let layers = document.getElementById("layers");
  let gameOver = document.getElementById("GameOver");

  MainMenu.style.display = "none";
  layers.style.display = "none";
  gameOver.style.display = "inline-block";
  
  Pause()
}

function SkorCalling(){
  let skor = document.getElementById("SkorGame");
  let skorrr = document.getElementById("Skor");

  skor.innerHTML = untangleGame.Skor;
  skorrr.value = untangleGame.Skor;
}

function StartTimer(){

timer = setInterval(()=>{

  if(untangleGame.Time > 0){
    untangleGame.Time -= 1
  }
  
},1000)
}

function Pause(){
  clearInterval(timer);
}

function Resetting() {
  document.getElementById("form").reset();
}
